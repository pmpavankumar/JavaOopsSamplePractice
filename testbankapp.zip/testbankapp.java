package day9;

class savingacc
{
	double balance;
	double intrest;
	public savingacc(double balance, double intrest) {
		super();
		this.balance = balance;
		this.intrest = intrest;
	}
	void withdraw(int amount)
	{
		balance=balance-amount;
	}
	void deposite(int amount)
	{
		balance=balance+amount;
	}
	void addmyintrest()
	{
		double intr =balance *( intrest/100);
balance+=intr;
	}
	public double getBalance() {
		double intr=balance * (intrest/100);
		balance+=intr;
		return balance;
	}
	
	
	
}

public class testbankapp {

	public static void main(String[] args) {
		savingacc s1 = new savingacc(2000.00,2.00);
		s1.deposite(500);
	System.out.println(s1.getBalance());
	}

}
