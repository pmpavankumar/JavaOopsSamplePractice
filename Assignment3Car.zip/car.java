package day9;

class car {
	int yearmodel;
	String make;
	int speed;
	
	public car(int yearmodel,String make) {
		this.yearmodel=yearmodel;
		this.make=make;
		speed=0;
	}

	public int getYearmodel() {
		return yearmodel;
	}

	public void setYearmodel(int yearmodel) {
		this.yearmodel = yearmodel;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}
public void accelerate()
{
	speed+=5;//this expreesion(increase spped by5)
}
public void brake()
{
	speed-=5;//decrease speed 5
	if(speed<0)
		speed=0;
	
}
}

