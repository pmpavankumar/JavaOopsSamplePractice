package day9;

public class cartestapp {

	public static void main(String[] args) {
		
		car c = new car(1965,"bat mobile");
		c.accelerate();
		System.out.println(c.getSpeed());
		c.accelerate();
		System.out.println(c.getSpeed());
		c.accelerate();
		System.out.println(c.getSpeed());
		c.accelerate();
		System.out.println(c.getSpeed());
		c.accelerate();
		System.out.println(c.getSpeed());
	    c.brake();
	    System.out.println(c.getSpeed());
	    c.brake();
	    System.out.println(c.getSpeed());
	    c.brake();
	    System.out.println(c.getSpeed());
	    c.brake();
	    System.out.println(c.getSpeed());
	    c.brake();
	    System.out.println(c.getSpeed());
	    c.brake();
	    System.out.println(c.getSpeed());
	
	}

}
